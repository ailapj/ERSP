import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.responsive = Tri.no ∧ c.pulseFelt = Tri.no ∧ c.breathing = Tri.yes

example : Ctx → Prop := rule
end YOriginal
