import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.inhaledWater = Tri.yes ∧
  c.coughing = Tri.yes ∧
  c.timeSaid = TimeSaid.dayOrMore ∧
  c.seemsRecovered = Tri.yes ∧
  c.responsive = Tri.yes ∧
  c.breathing = Tri.yes

example : Ctx → Prop := rule
end YPrime
