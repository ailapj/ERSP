-- Vocabulary for the drowning domain. Every field is what a caller reported,
-- not a clinical conclusion.

inductive Tri where
  | yes
  | no
  | unknown
  deriving DecidableEq

inductive AgeSaid where
  | child       -- "my son", "the kid", "my nephew"
  | adult
  | unspecified
  deriving DecidableEq

inductive TimeSaid where
  | now         -- happening as the caller speaks
  | earlier     -- minutes or hours ago
  | dayOrMore   -- "it's 24 hours later"
  | unspecified
  deriving DecidableEq

structure Ctx where
  ageSaid        : AgeSaid
  timeSaid       : TimeSaid
  wasSubmerged   : Tri   -- went under, fell in, was in the water
  outOfWater     : Tri   -- pulled out, rescued, got him out
  responsive     : Tri   -- awake, talking, answers
  breathing      : Tri
  coughing       : Tri
  inhaledWater   : Tri   -- swallowed or breathed in water
  seemsRecovered : Tri   -- woke up, seems okay now
