-- Vocabulary for the choking domain. Every field is what a caller reported,
-- not a clinical conclusion.

inductive Tri where
  | yes
  | no
  | unknown
  deriving DecidableEq

inductive AgeSaid where
  | baby        -- "my baby", "the infant", "nine week-old"
  | child       -- "my toddler", "my daughter", "the kid"
  | adult       -- "my husband", "my father", "my mom"
  | unspecified
  deriving DecidableEq

structure Ctx where
  ageSaid           : AgeSaid
  saidChoking       : Tri   -- the caller used the word "choking"
  swallowedOrEating : Tri   -- swallowed something, had food in the mouth, was eating
  clutchingThroat   : Tri   -- grabbing at the throat or neck
  makingSound       : Tri   -- can talk, cry, or make any sound
  coughing          : Tri
  breathing         : Tri
  turnedBlue        : Tri
  responsive        : Tri   -- answers, reacts, has not passed out
  helpPresent       : Tri   -- someone other than the casualty is there to act
