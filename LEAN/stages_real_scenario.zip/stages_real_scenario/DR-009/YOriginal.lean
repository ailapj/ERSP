import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.yes ∧
  c.timeSaid = TimeSaid.earlier

example : Ctx → Prop := rule
end YOriginal
