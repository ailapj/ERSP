import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.responsive = Tri.no ∧ c.breathing = Tri.no

example : Ctx → Prop := rule
end YOriginal
