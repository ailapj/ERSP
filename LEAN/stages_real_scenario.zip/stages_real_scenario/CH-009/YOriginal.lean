import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.swallowedOrEating = Tri.yes ∧
  c.saidChoking = Tri.no ∧
  c.coughing = Tri.no ∧
  c.breathing = Tri.yes ∧
  c.responsive = Tri.yes ∧
  c.helpPresent = Tri.yes

example : Ctx → Prop := rule
end YOriginal
