import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.outOfWater = Tri.yes ∧
  c.responsive = Tri.no ∧
  c.breathing = Tri.no ∧
  c.inhaledWater = Tri.yes

example : Ctx → Prop := rule
end YPrime
