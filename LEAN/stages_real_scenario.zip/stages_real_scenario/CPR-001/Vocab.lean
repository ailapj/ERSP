-- Vocabulary for the CPR domain. Every field is what a caller reported,
-- not a clinical conclusion.

inductive Tri where
  | yes
  | no
  | unknown
  deriving DecidableEq

inductive PrecedingEvent where
  | choking
  | drowning
  | none
  | unknown
  deriving DecidableEq

structure Ctx where
  foundDown       : Tri   -- collapsed, fainted, passed out, found on the floor
  responsive      : Tri   -- answers, reacts, wakes up
  breathing       : Tri   -- the caller said the person is breathing
  breathingNormal : Tri   -- the caller called that breathing normal, regular, quiet
  gasping         : Tri   -- snoring, gurgling, gasping, breathing "every once in a while"
  turnedBlue      : Tri
  pulseFelt       : Tri
  warmSkin        : Tri
  aedNearby       : Tri
  precededBy      : PrecedingEvent
