import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.inhaledWater = Tri.yes ∧ c.timeSaid = TimeSaid.earlier

example : Ctx → Prop := rule
end YOriginal
