import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.breathing = Tri.no

example : Ctx → Prop := rule
end YPrime
