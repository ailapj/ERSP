import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.swallowedOrEating = Tri.yes ∧
  c.saidChoking = Tri.no ∧
  c.clutchingThroat = Tri.no ∧
  c.makingSound = Tri.yes ∧
  c.coughing = Tri.yes ∧
  c.breathing = Tri.yes ∧
  c.turnedBlue = Tri.no ∧
  c.responsive = Tri.yes ∧
  c.helpPresent = Tri.yes

example : Ctx → Prop := rule
end YPrime
