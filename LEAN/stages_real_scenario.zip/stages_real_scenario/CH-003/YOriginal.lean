import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.baby ∧
  c.saidChoking = Tri.yes ∧
  c.swallowedOrEating = Tri.unknown ∧
  c.clutchingThroat = Tri.unknown ∧
  c.makingSound = Tri.unknown ∧
  c.coughing = Tri.unknown ∧
  c.breathing = Tri.unknown ∧
  c.turnedBlue = Tri.unknown ∧
  c.responsive = Tri.unknown ∧
  c.helpPresent = Tri.unknown

example : Ctx → Prop := rule
end YOriginal
