import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.adult ∧
  c.saidChoking = Tri.yes ∧
  c.helpPresent = Tri.no ∧
  c.responsive = Tri.yes ∧
  c.breathing = Tri.yes

example : Ctx → Prop := rule
end YOriginal
