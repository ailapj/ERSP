import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.baby ∧ c.saidChoking = Tri.yes

example : Ctx → Prop := rule
end YOriginal
