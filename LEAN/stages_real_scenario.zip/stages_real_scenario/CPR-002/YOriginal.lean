import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.foundDown = Tri.yes ∧
  c.responsive = Tri.no ∧
  c.precededBy = PrecedingEvent.none

example : Ctx → Prop := rule
end YOriginal
