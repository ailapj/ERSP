import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.timeSaid = TimeSaid.earlier ∧
  c.coughing = Tri.yes ∧
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.yes ∧
  c.responsive = Tri.yes ∧
  c.breathing = Tri.yes ∧
  c.inhaledWater = Tri.yes ∧
  c.seemsRecovered = Tri.yes

example : Ctx → Prop := rule
end YPrime
