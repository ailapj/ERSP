import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.inhaledWater = Tri.yes ∧
  c.breathing = Tri.yes ∧
  c.coughing = Tri.yes ∧
  c.responsive = Tri.yes

example : Ctx → Prop := rule
end YOriginal
