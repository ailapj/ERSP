import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.no ∧
  c.responsive = Tri.unknown ∧
  c.breathing = Tri.unknown ∧
  c.coughing = Tri.unknown ∧
  c.inhaledWater = Tri.unknown ∧
  c.seemsRecovered = Tri.unknown

example : Ctx → Prop := rule
end YOriginal
