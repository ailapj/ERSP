import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.baby ∧
  c.swallowedOrEating = Tri.yes ∧
  c.responsive = Tri.yes ∧
  c.breathing = Tri.yes ∧
  c.makingSound = Tri.yes ∧
  c.coughing = Tri.no ∧
  c.turnedBlue = Tri.no ∧
  c.clutchingThroat = Tri.no ∧
  c.saidChoking = Tri.no

example : Ctx → Prop := rule
end YOriginal
