import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.breathing = Tri.yes ∧ c.gasping = Tri.yes

example : Ctx → Prop := rule
end YOriginal
