import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.swallowedOrEating = Tri.yes ∧
  c.breathing = Tri.yes ∧
  c.responsive = Tri.yes ∧
  c.coughing = Tri.no ∧
  c.turnedBlue = Tri.no ∧
  c.helpPresent = Tri.unknown

example : Ctx → Prop := rule
end YPrime
