import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.breathing = .yes ∧ c.gasping = .no

example : Ctx → Prop := rule
end YOriginal
