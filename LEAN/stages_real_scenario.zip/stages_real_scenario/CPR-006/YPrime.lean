import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.breathing = Tri.yes ∧ c.gasping = Tri.no

example : Ctx → Prop := rule
end YPrime
