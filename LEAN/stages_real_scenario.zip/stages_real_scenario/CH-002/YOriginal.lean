import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.swallowedOrEating = Tri.yes ∧
  c.saidChoking = Tri.yes ∧
  c.clutchingThroat = Tri.yes ∧
  c.makingSound = Tri.no ∧
  c.coughing = Tri.no ∧
  c.breathing = Tri.no ∧
  c.turnedBlue = Tri.unknown ∧
  c.responsive = Tri.unknown ∧
  c.helpPresent = Tri.unknown

example : Ctx → Prop := rule
end YOriginal
