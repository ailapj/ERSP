import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.baby ∧ c.swallowedOrEating = Tri.yes ∧ c.makingSound = Tri.no ∧ c.coughing = Tri.no ∧ c.breathing = Tri.no ∧ c.turnedBlue = Tri.yes ∧ c.responsive = Tri.yes

example : Ctx → Prop := rule
end YOriginal
