import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.saidChoking = Tri.yes

example : Ctx → Prop := rule
end YPrime
