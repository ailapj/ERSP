import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.adult ∧
  c.saidChoking = Tri.unknown ∧
  c.swallowedOrEating = Tri.unknown ∧
  c.clutchingThroat = Tri.unknown ∧
  c.makingSound = Tri.no ∧
  c.coughing = Tri.unknown ∧
  c.breathing = Tri.unknown ∧
  c.turnedBlue = Tri.unknown ∧
  c.responsive = Tri.unknown

example : Ctx → Prop := rule
end YOriginal
