import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.foundDown = Tri.yes

example : Ctx → Prop := rule
end YPrime
