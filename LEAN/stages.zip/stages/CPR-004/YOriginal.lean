import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.breathing = Tri.no ∧ c.precededBy = PrecedingEvent.choking

example : Ctx → Prop := rule
end YOriginal
