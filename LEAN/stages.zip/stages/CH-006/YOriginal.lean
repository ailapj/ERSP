import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.adult ∧
  c.clutchingThroat = Tri.yes ∧
  c.makingSound = Tri.no

example : Ctx → Prop := rule
end YOriginal
