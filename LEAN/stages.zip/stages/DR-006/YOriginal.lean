import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.outOfWater = Tri.yes ∧ c.responsive = Tri.no

example : Ctx → Prop := rule
end YOriginal
