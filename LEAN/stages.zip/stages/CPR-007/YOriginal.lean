import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.pulseFelt = Tri.no

example : Ctx → Prop := rule
end YOriginal
