import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.pulseFelt = Tri.no

example : Ctx → Prop := rule
end YPrime
