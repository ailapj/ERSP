import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.saidChoking = .yes ∧ c.swallowedOrEating = .yes ∧ c.clutchingThroat = .yes ∧ c.makingSound = .no ∧ c.coughing = .no ∧ c.breathing = .yes ∧ c.turnedBlue = .no ∧ c.responsive = .yes

example : Ctx → Prop := rule
end YOriginal
