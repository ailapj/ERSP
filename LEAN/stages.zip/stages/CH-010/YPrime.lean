import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.saidChoking = Tri.yes ∧
  c.swallowedOrEating = Tri.yes ∧
  c.clutchingThroat = Tri.yes ∧
  c.makingSound = Tri.no ∧
  c.coughing = Tri.no ∧
  c.breathing = Tri.yes ∧
  c.turnedBlue = Tri.no ∧
  c.responsive = Tri.yes

example : Ctx → Prop := rule
end YPrime
