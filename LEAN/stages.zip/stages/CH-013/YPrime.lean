import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.clutchingThroat = Tri.yes

example : Ctx → Prop := rule
end YPrime
