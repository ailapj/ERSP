import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.foundDown = Tri.yes ∧ c.responsive = Tri.no

example : Ctx → Prop := rule
end YPrime
