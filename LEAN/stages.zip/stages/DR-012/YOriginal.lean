import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.no ∧
  c.responsive = Tri.no ∧
  c.breathing = Tri.no

example : Ctx → Prop := rule
end YOriginal
