import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  (c.wasSubmerged = .yes ∧ c.outOfWater ≠ .yes) ∨
  (c.outOfWater = .yes ∧ c.responsive = .no ∧ c.breathing = .no) ∨
  (c.outOfWater = .yes ∧ c.responsive = .yes ∧ c.breathing = .yes ∧ c.coughing = .yes) ∨
  (c.outOfWater = .yes ∧ c.responsive = .yes ∧ c.breathing = .yes ∧ c.coughing = .no ∧ c.inhaledWater = .yes) ∨
  (c.outOfWater = .yes ∧ c.responsive = .yes ∧ c.breathing = .yes ∧ c.coughing = .no ∧ c.inhaledWater = .no ∧ c.seemsRecovered = .no) ∨
  (c.outOfWater = .yes ∧ c.responsive = .yes ∧ c.breathing = .yes ∧ c.coughing = .no ∧ c.inhaledWater = .no ∧ c.seemsRecovered = .yes ∧ c.ageSaid = .child)

example : Ctx → Prop := rule
end YOriginal
