import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.foundDown = .yes ∧ c.responsive = .no ∧ c.breathing = .no

example : Ctx → Prop := rule
end YPrime
