import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.yes

example : Ctx → Prop := rule
end YPrime
