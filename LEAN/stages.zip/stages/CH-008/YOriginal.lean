import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.turnedBlue = Tri.yes ∧ (c.swallowedOrEating = Tri.yes ∨ c.swallowedOrEating = Tri.unknown)

example : Ctx → Prop := rule
end YOriginal
