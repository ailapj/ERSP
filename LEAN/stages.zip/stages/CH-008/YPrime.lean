import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.turnedBlue = .yes ∧
    (c.swallowedOrEating = .yes ∨ c.swallowedOrEating = .unknown)

example : Ctx → Prop := rule
end YPrime
