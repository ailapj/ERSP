import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.wasSubmerged = Tri.yes ∧ c.outOfWater = Tri.unknown

example : Ctx → Prop := rule
end YPrime
