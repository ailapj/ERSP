import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.wasSubmerged = Tri.yes ∧
  ∃ t : Tri, t = Tri.unknown ∧ c.outOfWater = t

example : Ctx → Prop := rule
end YOriginal
