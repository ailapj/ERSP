import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.responsive = Tri.no ∧ c.saidChoking = Tri.yes

example : Ctx → Prop := rule
end YPrime
