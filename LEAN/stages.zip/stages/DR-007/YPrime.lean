import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.inhaledWater = Tri.yes ∧
  c.coughing = Tri.yes

example : Ctx → Prop := rule
end YPrime
