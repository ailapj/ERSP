import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.adult ∧
  (c.swallowedOrEating = Tri.yes) ∧
  c.makingSound = Tri.no

example : Ctx → Prop := rule
end YPrime
