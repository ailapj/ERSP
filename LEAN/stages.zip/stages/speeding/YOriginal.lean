import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  (c.zone = Zone.school → c.speedKph > 30 → ¬ c.hasPermit → c.isViolation) ∧
  (c.zone = Zone.school → c.hasPermit → ¬ c.isViolation) ∧
  (c.zone = Zone.residential → c.speedKph > 50 → c.isViolation) ∧
  (c.zone = Zone.residential → c.speedKph ≤ 50 → ¬ c.isViolation) ∧
  (c.zone = Zone.highway → ¬ c.isViolation) ∧
  (c.speedKph ≤ 30 → ¬ c.isViolation)

example : Ctx → Prop := rule
end YOriginal
