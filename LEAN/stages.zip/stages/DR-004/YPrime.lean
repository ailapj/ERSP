import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.outOfWater = Tri.yes ∧ c.seemsRecovered = Tri.yes

example : Ctx → Prop := rule
end YPrime
