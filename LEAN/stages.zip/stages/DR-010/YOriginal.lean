import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.wasSubmerged = Tri.yes

example : Ctx → Prop := rule
end YOriginal
