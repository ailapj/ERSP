import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.saidChoking = Tri.yes ∧
  c.swallowedOrEating = Tri.yes ∧
  c.clutchingThroat = Tri.yes ∧
  c.makingSound = Tri.no ∧
  c.coughing = Tri.no ∧
  c.breathing = Tri.no ∧
  c.turnedBlue = Tri.yes ∧
  c.responsive = Tri.no

example : Ctx → Prop := rule
end YOriginal
