import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.inhaledWater = Tri.yes

example : Ctx → Prop := rule
end YPrime
