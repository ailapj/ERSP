import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.inhaledWater = Tri.yes

example : Ctx → Prop := rule
end YOriginal
