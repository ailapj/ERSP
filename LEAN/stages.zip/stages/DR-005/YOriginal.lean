import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.coughing = Tri.yes ∧ c.wasSubmerged = Tri.yes

example : Ctx → Prop := rule
end YOriginal
