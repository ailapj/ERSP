import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.baby ∧
  c.makingSound = Tri.no ∧
  (c.swallowedOrEating = Tri.yes)

example : Ctx → Prop := rule
end YPrime
