import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.aedNearby = Tri.yes

example : Ctx → Prop := rule
end YOriginal
