import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.aedNearby = Tri.yes

example : Ctx → Prop := rule
end YPrime
