import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.child ∧
  c.wasSubmerged = Tri.yes ∧
  c.outOfWater = Tri.yes ∧
  c.responsive = Tri.no ∧
  c.breathing = Tri.no

example : Ctx → Prop := rule
end YPrime
