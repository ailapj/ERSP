import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.passes = true ↔
    c.cheated = false ∧
    c.finalExamScore ≥ 80 ∧
    c.attendancePct ≥ 80

example : Ctx → Prop := rule
end YPrime
