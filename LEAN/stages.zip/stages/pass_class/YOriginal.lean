import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.passes ↔ (¬ c.cheated ∧ c.finalExamScore ≥ 80 ∧ c.attendancePct ≥ 80)

example : Ctx → Prop := rule
end YOriginal
