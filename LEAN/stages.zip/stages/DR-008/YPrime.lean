import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.breathing = Tri.no ∧ c.wasSubmerged = Tri.yes

example : Ctx → Prop := rule
end YPrime
