import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  c.ageSaid = AgeSaid.unspecified ∧
  c.saidChoking = Tri.unknown ∧
  c.swallowedOrEating = Tri.unknown ∧
  c.clutchingThroat = Tri.unknown ∧
  c.coughing = Tri.unknown ∧
  c.breathing = Tri.unknown ∧
  c.turnedBlue = Tri.unknown ∧
  c.responsive = Tri.unknown ∧
  c.makingSound = Tri.no

example : Ctx → Prop := rule
end YPrime
