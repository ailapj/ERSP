import Vocab

namespace YOriginal
def rule (c : Ctx) : Prop :=
  c.swallowedOrEating = .yes ∧ c.makingSound = .yes

example : Ctx → Prop := rule
end YOriginal
