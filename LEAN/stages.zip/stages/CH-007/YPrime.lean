import Vocab

namespace YPrime
def rule (c : Ctx) : Prop :=
  (c.swallowedOrEating = Tri.yes) ∧ (c.makingSound = Tri.yes)

example : Ctx → Prop := rule
end YPrime
